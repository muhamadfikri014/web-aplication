Aplikasi perpustakaan ini adalah aplikasi yg saya kembangkan dari internet
saya juga mengucapkan terimakasih banyak atas pembuat pertama aplikasi ini
karena saya banyak belajar dari app tersebbut. pengembangan meliputi :

1. Penggunaan library template . sehingga hemat script untuk templatingnya
2. Sudah menggunakan sbadmin bootstrap sehingga tampilan lebih enak dipandang
3. Untuk login juga sudah menggunakan bycrpt sehingga lebih secure. walapun dalam sebuah website
   tidak ada 100% sistem yg aman. paling gak mengurangi celah
4. Menggunakan datatable untuk penyajian datanya (blm server side)
5. Silakan kembangkan lebih dalam lagi jika anda tertarik untuk mempelajari app ini.

6. proses login 
   Username : admin
   Password : admin

Salam Hangat 


~ Panji Asmoro ~